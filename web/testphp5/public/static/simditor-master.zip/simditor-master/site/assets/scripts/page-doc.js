(function() {
  $(function() {
    var $page;
    return $page = $('.page-doc');
  });

}).call(this);
